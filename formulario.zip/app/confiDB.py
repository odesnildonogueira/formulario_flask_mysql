import mysql.connector

def connectionBD():
    mydb = mysql.connector.connect(
        host ="localhost",
        user ="recepcao",
        passwd ="123",
        database = "dbescola"
        )
    if mydb:
        print ("Conexão bem-sucedida")
    else:
        print ("Erro ao conectar ao banco de dados")
    return mydb